# BaseConverter
Team project to convert between base 2 and 10 as well as base 2 and 16 in C++
