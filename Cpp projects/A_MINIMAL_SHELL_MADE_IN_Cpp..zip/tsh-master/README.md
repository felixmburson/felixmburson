# TSH

A minimal shell made in C++.

![TSH](/github/screenshot.png?raw=true "TSH in action")

## Building from Source
Go to the project root and enter the command

    make

The project executeable is /build/tsh

TSH supports multiple commands and pipes. Command history is saved in ~/.tsh_history file.
